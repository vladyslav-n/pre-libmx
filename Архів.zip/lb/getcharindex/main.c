#include "../inc/libmx.h"
#include <stdio.h>
#define DEBUG

int main()
{
    char *str = "";
    printf("%d", mx_get_char_index(str, '6'));
}

