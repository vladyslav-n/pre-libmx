#include <stdio.h>

int mx_strcmp(const char *s1, const char *s2);
int mx_binary_search(char **arr, int size, const char *s, int *count);

int main() {
    int count = 1000;
    char *arr[] = {"222", "Abcd", "aBc", "ab", "az", "z"};
    char *arr1[] = {"1", "2", "3", "4"};
    printf("%d %d\n", mx_binary_search(arr, 6, "ab", &count), count);
    printf("%d %d\n", mx_binary_search(arr, 6, "aBc", &count), count);
    printf("%d %d\n", mx_binary_search(arr1, 4, "5", &count), count);
    printf("%d %d\n", mx_binary_search(arr1, 0, "0", &count), count);
}

