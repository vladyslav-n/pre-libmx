#include <stdio.h>
void mx_sort_arr_int(int *arr, int size);

int main() {
    int arr[] = {3, 55, -11, 1, 0, 4, 22};

    mx_sort_arr_int(arr, 7); //arr now is '{-11, 0, 1, 3, 4, 22, 55}'
    for (int i = 0; i < 7; i++)
    {
        printf("%d ", arr[i]);
    }
}

