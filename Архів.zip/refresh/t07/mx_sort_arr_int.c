void mx_sort_arr_int(int *arr, int size)
{
    char flag = 1;
    int buf = 0;
    int count = 1;
    while (flag) 
    {
        flag = 0;
        for (int i = 0; i < size - count; i++)
        {
            if (arr[i] > arr[i + 1]) 
            {
                buf = arr[i];
                arr[i] = arr[i + 1];
                arr[i + 1] = buf;
                flag = 1;
            }
        }
        count += 1;
    }
}

