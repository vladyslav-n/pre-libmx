#include <stdio.h>
int mx_sqrt(int x);

int main() {

    printf("%d\n", mx_sqrt(2147483647));
    printf("%d\n", mx_sqrt(-2147483648));
    printf("%d\n", mx_sqrt(0));
    printf("%d\n", mx_sqrt(2));
    printf("%d\n", mx_sqrt(9));
    printf("%d\n", mx_sqrt(144));
    printf("%d\n", mx_sqrt(143));
    printf("%d\n", mx_sqrt(-143));

}

