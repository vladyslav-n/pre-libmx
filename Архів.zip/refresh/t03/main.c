#include <stdio.h>
void mx_printstr(const char *s);

int main() {
mx_printstr("Word");
    // printf("%d\n", mx_sqrt(2147483647));
    // printf("%d\n", mx_sqrt(-2147483648));
    // printf("%d\n", mx_sqrt(0));
    // printf("%d\n", mx_sqrt(2));
    // printf("%d\n", mx_sqrt(9));
    // printf("%d\n", mx_sqrt(144));
    // printf("%d\n", mx_sqrt(143));
    // printf("%d\n", mx_sqrt(-143));

}

