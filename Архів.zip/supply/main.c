#include <stdio.h>
//#include <unistd.h>
//#include <stdbool.h>
//#include <string.h>
#include <stdlib.h>
int mx_atoi(const char *str);

int main() {
//    char str1[] = "Word1Ajjk";
  //  char str2[] = "wofffrd\0j";
    //strcpy(str2, str1);
       printf("%d\n", atoi(" 000190005"));
    printf("%d\n", mx_atoi(" 000190005"));
    return 0;
}
