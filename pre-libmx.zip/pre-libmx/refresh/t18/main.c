#include <stdio.h>
void mx_foreach(int *arr, int size, void (*f)(int));

void f(int x) {
    printf("%d\n", x);
}

int main() {
    int arr[] = {1, 2, 3, 4, 5};
    mx_foreach(arr, 5, f); //prints "12345" on the standart output
    // printf("%lu\n", mx_hex_to_nbr("C4"));
    // printf("%lu\n", mx_hex_to_nbr("FADE"));
   
}

