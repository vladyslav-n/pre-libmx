#include <stdio.h>

int mx_strcmp(const char *s1, const char *s2);
int mx_bubble_sort(char **arr, int size);

int main() {
    const char **arr = {"abc4", "xyz", "ghi", "def"};
    printf("%d", mx_bubble_sort(arr, 4));  //returns 3
}

