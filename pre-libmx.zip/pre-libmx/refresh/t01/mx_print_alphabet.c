#include <unistd.h>
void mx_printchar();

void mx_print_alphabet(void) {
    short int i;
    for (i = 0; i < 13; i++) 
    {
        mx_printchar(i * 2 + 65);
        mx_printchar(i * 2 + 98);
    }
    write (1, "\n", 1);    
}

