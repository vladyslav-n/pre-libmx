#include <stdio.h>
double mx_pow(double n, unsigned int pow);

int main() {
    printf("%e.25\n", mx_pow(1.0000001, 4294967295));
}

