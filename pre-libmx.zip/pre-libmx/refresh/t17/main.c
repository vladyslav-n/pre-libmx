#include <stdio.h>

unsigned long mx_hex_to_nbr(const char *hex);
char hexchar(char c);

int main() {
    // char *arr = {"222", "Abcd", "aBc", "ab", "az", "z"};
    // char *arr1 = {"1", "2", "3", "4"};
    printf("%lu\n", mx_hex_to_nbr("C4"));
    printf("%lu\n", mx_hex_to_nbr("FADE"));
    printf("%lu\n", mx_hex_to_nbr("ffffffffffff"));
    printf("%lu\n", mx_hex_to_nbr("0"));
    // printf("%c\n", hexchar('A'));
    // printf("%c\n", hexchar('a'));
    // printf("%c\n", hexchar('b'));
    // printf("%c\n", hexchar('B'));
    // printf("%c\n", hexchar('c'));
    // printf("%c\n", hexchar('d'));
    // printf("%c\n", hexchar('e'));
    // printf("%c\n", hexchar('F'));
}

