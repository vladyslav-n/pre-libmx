#include <stdio.h>
void mx_printint(int n);

int main() {

     mx_printint(2147483647);
     mx_printint(-2147483648);
     mx_printint(0);
     mx_printint(2);
     mx_printint(9);
     mx_printint(144);
     mx_printint(143);
     mx_printint(-143);

}

