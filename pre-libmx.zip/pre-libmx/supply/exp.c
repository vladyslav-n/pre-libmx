#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

int main() {
//    char str1[] = "Word1Ajjk";
  //  char str2[] = "wofffrd\0j";
    //strcpy(str2, str1);
    printf("%d\n", atoi("0-1  0005 0 76"));
    return 0;
}
