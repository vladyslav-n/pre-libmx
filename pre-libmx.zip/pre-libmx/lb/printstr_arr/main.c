#include "../inc/libmx.h"

 #include <stdio.h>
int main() {
    // const char *delim = "...";
    // char **arr = NULL;
    char *arr[] = {"LOWcZhLIHLNJX", "Gd2a9uNVpOKtr", "HL1Ig 1D9EtnwiE", "PmktRdNOAeAZ4", "ki  KIcfZf m6P", "OiH3VIE4JYi", "BI2n5okMuD", "xytjNvF6Im", "OUF1axUuNV", "pdhG6ok4sea", "zfdjOmij5nk", "cMuyxDqiF0", "rM k0w    1H NBy", "YJ9ZL9QS8z4t", NULL};
    const char *delim = "______";
    mx_print_strarr(arr, delim);
}

