#include "../inc/libmx.h"
#include <stdio.h>
#define DEBUG

int main()
{
    printf("%s\n", mx_replace_substr("Ururu turu", "ru", "|--------------------|"));
}

