#include "../inc/libmx.h"

 #include <stdio.h>
int main() {
    //mx_print_unicode(0x1F710);
    mx_print_unicode(0xA606);
    mx_print_unicode('\n');
}

