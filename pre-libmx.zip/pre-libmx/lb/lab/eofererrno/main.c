#include "../inc/libmx.h"
#include <stdio.h>
void eoferrno_test(const char *file);


int main() {
    eoferrno_test("copy");
}

