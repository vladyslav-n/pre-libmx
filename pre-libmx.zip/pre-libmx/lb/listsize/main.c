#include "../inc/libmx.h"
#include <stdio.h>
#define DEBUG

int main()
{
  t_list *arr = NULL;
  
    // t_list *arr[4];
    // for (int i = 0; i < 4; i++)
    // {
    //     arr[i] = mx_create_node(NULL);
    // }
    // for (int i = 0; i < 3; i++)
    // {
    //     arr[i]->next = arr[i + 1];
    // }
    
    // //     t_list *arr[1];
    // // for (int i = 0; i < 1; i++)
    // // {
    // //     arr[i] = mx_create_node(NULL);
    // // }
    // // for (int i = 0; i < 0; i++)
    // // {
    // //     arr[i]->next = arr[i + 1];
    // // }

    printf("%d\n", mx_list_size(arr));
}

