#include "../inc/libmx.h"
#include <stdio.h>
#define DEBUG

int main()
{
    
}

